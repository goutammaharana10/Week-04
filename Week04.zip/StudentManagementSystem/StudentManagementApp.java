import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class StudentManagementApp {
    private static final Scanner sc = new Scanner(System.in);
    private static final StudentController controller = new StudentController();

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static String readText(String message) {
        System.out.print(message);
        return sc.nextLine().trim();
    }

    private static Student inputStudent(int id) {
        String name = readText("Enter name: ");
        String course = readText("Enter course: ");
        String email = readText("Enter email: ");
        int age = readInt("Enter age: ");
        if (name.isEmpty() || course.isEmpty() || email.isEmpty() || age <= 0) {
            throw new IllegalArgumentException("Fields cannot be empty and age must be positive.");
        }
        return new Student(id, name, course, email, age);
    }

    private static void showAll() throws SQLException {
        List<Student> students = controller.getAll();
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.printf("%-8s %-22s %-15s %-28s %-5s%n",
                "ID", "NAME", "COURSE", "EMAIL", "AGE");
        for (Student s : students) s.display();
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("\\n===== STUDENT MANAGEMENT SYSTEM =====");
            System.out.println("1. Add student");
            System.out.println("2. View all students");
            System.out.println("3. Search student");
            System.out.println("4. Update student");
            System.out.println("5. Delete student");
            System.out.println("6. Exit");
            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {
                    case 1: {
                        int id = readInt("Enter student ID: ");
                        Student s = inputStudent(id);
                        System.out.println(controller.add(s) ?
                                "Student added successfully." : "Student was not added.");
                        break;
                    }
                    case 2:
                        showAll();
                        break;
                    case 3: {
                        int id = readInt("Enter ID to search: ");
                        Student s = controller.search(id);
                        if (s == null) System.out.println("Student not found.");
                        else {
                            System.out.printf("%-8s %-22s %-15s %-28s %-5s%n",
                                    "ID", "NAME", "COURSE", "EMAIL", "AGE");
                            s.display();
                        }
                        break;
                    }
                    case 4: {
                        int id = readInt("Enter ID to update: ");
                        if (controller.search(id) == null) {
                            System.out.println("Student not found.");
                        } else {
                            Student s = inputStudent(id);
                            System.out.println(controller.update(s) ?
                                    "Student updated successfully." : "Update failed.");
                        }
                        break;
                    }
                    case 5: {
                        int id = readInt("Enter ID to delete: ");
                        System.out.println(controller.delete(id) ?
                                "Student deleted successfully." : "Student not found.");
                        break;
                    }
                    case 6:
                        System.out.println("Exiting Student Management System.");
                        sc.close();
                        return;
                    default:
                        System.out.println("Invalid menu choice.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid student details: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
                System.out.println("Check MySQL is running, database.sql was executed, and DB credentials are correct.");
            }
        }
    }
}
