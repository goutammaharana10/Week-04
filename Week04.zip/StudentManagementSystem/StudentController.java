import java.sql.SQLException;
import java.util.List;

public class StudentController {
    private StudentDAO dao = new StudentDAO();

    public boolean add(Student s) throws SQLException { return dao.addStudent(s); }
    public boolean update(Student s) throws SQLException { return dao.updateStudent(s); }
    public boolean delete(int id) throws SQLException { return dao.deleteStudent(id); }
    public Student search(int id) throws SQLException { return dao.findStudent(id); }
    public List<Student> getAll() throws SQLException { return dao.getAllStudents(); }
}
