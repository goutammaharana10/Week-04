public class Student {
    private int id;
    private String name;
    private String course;
    private String email;
    private int age;

    public Student(int id, String name, String course, String email, int age) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.email = email;
        this.age = age;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCourse() { return course; }
    public String getEmail() { return email; }
    public int getAge() { return age; }

    public void setName(String name) { this.name = name; }
    public void setCourse(String course) { this.course = course; }
    public void setEmail(String email) { this.email = email; }
    public void setAge(int age) { this.age = age; }

    public void display() {
        System.out.printf("%-8d %-22s %-15s %-28s %-5d%n",
                id, name, course, email, age);
    }
}
