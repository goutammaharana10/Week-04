import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HotelService {
    private static final String FILE_NAME = "hotel_bookings.txt";
    private final List<Booking> bookings = new ArrayList<Booking>();

    public HotelService() {
        loadBookings();
    }

    public double getRate(String roomType) {
        if (roomType.equalsIgnoreCase("standard")) return 1500.0;
        if (roomType.equalsIgnoreCase("deluxe")) return 2500.0;
        if (roomType.equalsIgnoreCase("suite")) return 4000.0;
        return -1;
    }

    public Booking addBooking(String name, String roomType, int nights) {
        if (name == null || name.trim().isEmpty() || name.contains("|") || nights <= 0) {
            throw new IllegalArgumentException("Enter a valid customer name and a positive number of nights.");
        }
        String normalizedType = roomType.toLowerCase();
        double rate = getRate(normalizedType);
        if (rate < 0) throw new IllegalArgumentException("Room type must be Standard, Deluxe, or Suite.");

        int id = nextBookingId();
        Booking booking = new Booking(id, name.trim(), capitalize(normalizedType),
                nights, rate * nights);
        bookings.add(booking);
        saveBookings();
        return booking;
    }

    private String capitalize(String value) {
        return value.substring(0, 1).toUpperCase() + value.substring(1);
    }

    private int nextBookingId() {
        int max = 1000;
        for (Booking b : bookings) if (b.getBookingId() > max) max = b.getBookingId();
        return max + 1;
    }

    public boolean cancelBooking(int id) {
        for (int i = 0; i < bookings.size(); i++) {
            if (bookings.get(i).getBookingId() == id) {
                bookings.remove(i);
                saveBookings();
                return true;
            }
        }
        return false;
    }

    public List<Booking> getBookings() {
        return new ArrayList<Booking>(bookings);
    }

    private void saveBookings() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (Booking b : bookings) pw.println(b.toFileLine());
        } catch (IOException e) {
            System.out.println("Could not save bookings: " + e.getMessage());
        }
    }

    private void loadBookings() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    String[] p = line.split("\\\\|", -1);
                    if (p.length != 5) continue;
                    int id = Integer.parseInt(p[0]);
                    int nights = Integer.parseInt(p[3]);
                    double total = Double.parseDouble(p[4]);
                    if (id > 0 && nights > 0 && total >= 0 &&
                            !p[1].trim().isEmpty() && !p[2].trim().isEmpty()) {
                        bookings.add(new Booking(id, p[1], p[2], nights, total));
                    }
                } catch (NumberFormatException ignored) {
                    // Skip malformed records and continue loading the valid records.
                }
            }
        } catch (IOException e) {
            System.out.println("Could not load bookings: " + e.getMessage());
        }
    }
}
