public class Booking {
    private int bookingId;
    private String customerName;
    private String roomType;
    private int nights;
    private double totalCost;

    public Booking(int bookingId, String customerName, String roomType,
                   int nights, double totalCost) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.roomType = roomType;
        this.nights = nights;
        this.totalCost = totalCost;
    }

    public int getBookingId() { return bookingId; }
    public String getCustomerName() { return customerName; }
    public String getRoomType() { return roomType; }
    public int getNights() { return nights; }
    public double getTotalCost() { return totalCost; }

    public String toFileLine() {
        return bookingId + "|" + customerName + "|" + roomType + "|" + nights + "|" + totalCost;
    }

    public void display() {
        System.out.printf("%-8d %-22s %-12s %-8d Rs. %.2f%n",
                bookingId, customerName, roomType, nights, totalCost);
    }
}
