import java.util.List;
import java.util.Scanner;

public class HotelBookingApp {
    private static final Scanner sc = new Scanner(System.in);

    private static int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static void showBookings(HotelService service) {
        List<Booking> list = service.getBookings();
        if (list.isEmpty()) {
            System.out.println("No bookings found.");
            return;
        }
        System.out.printf("%-8s %-22s %-12s %-8s %s%n",
                "ID", "CUSTOMER", "ROOM", "NIGHTS", "TOTAL COST");
        for (Booking b : list) b.display();
    }

    public static void main(String[] args) {
        HotelService service = new HotelService();

        while (true) {
            System.out.println("\\n===== HOTEL BOOKING MANAGEMENT =====");
            System.out.println("Room rates per night:");
            System.out.println("Standard: Rs. 1500 | Deluxe: Rs. 2500 | Suite: Rs. 4000");
            System.out.println("1. Add booking");
            System.out.println("2. View all bookings");
            System.out.println("3. Cancel booking");
            System.out.println("4. Exit");
            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter customer name: ");
                        String name = sc.nextLine().trim();
                        System.out.print("Enter room type (Standard/Deluxe/Suite): ");
                        String type = sc.nextLine().trim();
                        int nights = readInt("Enter number of nights: ");
                        Booking booking = service.addBooking(name, type, nights);
                        System.out.println("Booking created successfully!");
                        System.out.println("Booking ID: " + booking.getBookingId());
                        System.out.printf("Total cost: Rs. %.2f%n", booking.getTotalCost());
                        break;
                    case 2:
                        showBookings(service);
                        break;
                    case 3:
                        int id = readInt("Enter booking ID to cancel: ");
                        System.out.println(service.cancelBooking(id) ?
                                "Booking cancelled successfully." : "Booking ID not found.");
                        break;
                    case 4:
                        System.out.println("Thank you for using the hotel system.");
                        sc.close();
                        return;
                    default:
                        System.out.println("Invalid menu choice.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid booking: " + e.getMessage());
            }
        }
    }
}
