import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ATMService {
    private static final String ACCOUNT_FILE = "atm_account.txt";
    private static final String HISTORY_FILE = "transactions.txt";
    private BankAccount account;

    public ATMService() {
        loadAccount();
    }

    private void loadAccount() {
        File file = new File(ACCOUNT_FILE);
        if (!file.exists()) {
            account = new BankAccount("1234", 5000.00);
            saveAccount();
            record("Account created with opening balance Rs. 5000.00");
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String pin = br.readLine();
            String balance = br.readLine();
            account = new BankAccount(pin, Double.parseDouble(balance));
        } catch (Exception e) {
            System.out.println("Account file was invalid. Creating a demo account.");
            account = new BankAccount("1234", 5000.00);
            saveAccount();
        }
    }

    private void saveAccount() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ACCOUNT_FILE))) {
            pw.println(account.getPin());
            pw.println(account.getBalance());
        } catch (IOException e) {
            System.out.println("Could not save account: " + e.getMessage());
        }
    }

    private void record(String message) {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        try (PrintWriter pw = new PrintWriter(new FileWriter(HISTORY_FILE, true))) {
            pw.println(time + " | " + message);
        } catch (IOException e) {
            System.out.println("Could not save transaction history.");
        }
    }

    public boolean login(String pin) {
        return account.checkPin(pin);
    }

    public boolean deposit(double amount) {
        if (amount <= 0) return false;
        account.deposit(amount);
        saveAccount();
        record(String.format("Deposit: Rs. %.2f | Balance: Rs. %.2f", amount, account.getBalance()));
        return true;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0 || !account.withdraw(amount)) return false;
        saveAccount();
        record(String.format("Withdrawal: Rs. %.2f | Balance: Rs. %.2f", amount, account.getBalance()));
        return true;
    }

    public double getBalance() {
        return account.getBalance();
    }

    public boolean changePin(String oldPin, String newPin) {
        if (!account.checkPin(oldPin) || newPin == null || !newPin.matches("\\\\d{4}")) return false;
        account.changePin(newPin);
        saveAccount();
        record("PIN changed successfully");
        return true;
    }

    public List<String> getHistory() {
        List<String> history = new ArrayList<String>();
        File file = new File(HISTORY_FILE);
        if (!file.exists()) return history;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) history.add(line);
        } catch (IOException e) {
            history.add("Unable to read transaction history.");
        }
        return history;
    }
}
