import java.util.List;
import java.util.Scanner;

public class ATMApp {
    private static final Scanner sc = new Scanner(System.in);

    private static double readAmount() {
        try {
            System.out.print("Enter amount: Rs. ");
            return Double.parseDouble(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static void main(String[] args) {
        ATMService atm = new ATMService();
        System.out.println("========== JAVA ATM ==========");
        System.out.println("Demo PIN on first run: 1234");

        boolean loggedIn = false;
        for (int attempts = 1; attempts <= 3; attempts++) {
            System.out.print("Enter 4-digit PIN: ");
            if (atm.login(sc.nextLine().trim())) {
                loggedIn = true;
                break;
            }
            System.out.println("Incorrect PIN. Attempts left: " + (3 - attempts));
        }
        if (!loggedIn) {
            System.out.println("Too many incorrect attempts. Exiting.");
            sc.close();
            return;
        }

        while (true) {
            System.out.println("\\n===== ATM MENU =====");
            System.out.println("1. Check balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transaction history");
            System.out.println("5. Change PIN");
            System.out.println("6. Logout");
            System.out.print("Choose option: ");
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1":
                    System.out.printf("Available balance: Rs. %.2f%n", atm.getBalance());
                    break;
                case "2": {
                    double amount = readAmount();
                    if (atm.deposit(amount)) System.out.println("Deposit successful.");
                    else System.out.println("Invalid amount. Enter an amount greater than zero.");
                    break;
                }
                case "3": {
                    double amount = readAmount();
                    if (atm.withdraw(amount)) System.out.println("Withdrawal successful.");
                    else System.out.println("Invalid amount or insufficient balance.");
                    break;
                }
                case "4": {
                    List<String> history = atm.getHistory();
                    System.out.println("----- TRANSACTION HISTORY -----");
                    if (history.isEmpty()) System.out.println("No transactions found.");
                    for (String item : history) System.out.println(item);
                    break;
                }
                case "5":
                    System.out.print("Enter current PIN: ");
                    String oldPin = sc.nextLine().trim();
                    System.out.print("Enter new 4-digit PIN: ");
                    String newPin = sc.nextLine().trim();
                    System.out.println(atm.changePin(oldPin, newPin) ?
                            "PIN changed successfully." : "PIN change failed. Check current PIN and new PIN format.");
                    break;
                case "6":
                    System.out.println("Logged out. Thank you.");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
