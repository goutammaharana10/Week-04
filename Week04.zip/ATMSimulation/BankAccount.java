public class BankAccount {
    private String pin;
    private double balance;

    public BankAccount(String pin, double balance) {
        this.pin = pin;
        this.balance = balance;
    }

    public String getPin() { return pin; }
    public double getBalance() { return balance; }

    public boolean checkPin(String enteredPin) {
        return pin.equals(enteredPin);
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0 || amount > balance) return false;
        balance -= amount;
        return true;
    }

    public void changePin(String newPin) {
        pin = newPin;
    }
}
